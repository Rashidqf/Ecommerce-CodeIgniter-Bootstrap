<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2026-10-13 12:55:37 --> Query error: Unknown column 'shop_categories.image' in 'field list' - Invalid query: SELECT shop_categories.sub_for, shop_categories.id, shop_categories.image, shop_categories_translations.name, (SELECT COUNT(*) FROM products WHERE products.shop_categorie = shop_categories.id AND products.visibility = 1 AND products.quantity > 0 AND products.vendor_id = 0) AS product_count
FROM `shop_categories_translations`
INNER JOIN `shop_categories` ON `shop_categories`.`id` = `shop_categories_translations`.`for_id`
WHERE `abbr` = 'en'
ORDER BY `position` ASC
ERROR - 2026-10-13 12:55:53 --> Query error: Unknown column 'shop_categories.image' in 'field list' - Invalid query: SELECT shop_categories.sub_for, shop_categories.id, shop_categories.image, shop_categories_translations.name, (SELECT COUNT(*) FROM products WHERE products.shop_categorie = shop_categories.id AND products.visibility = 1 AND products.quantity > 0 AND products.vendor_id = 0) AS product_count
FROM `shop_categories_translations`
INNER JOIN `shop_categories` ON `shop_categories`.`id` = `shop_categories_translations`.`for_id`
WHERE `abbr` = 'en'
ORDER BY `position` ASC
ERROR - 2026-10-13 12:57:47 --> Query error: Unknown column 'shop_categories.image' in 'field list' - Invalid query: SELECT shop_categories.sub_for, shop_categories.id, shop_categories.image, shop_categories_translations.name, (SELECT COUNT(*) FROM products WHERE products.shop_categorie = shop_categories.id AND products.visibility = 1 AND products.quantity > 0 AND products.vendor_id = 0) AS product_count
FROM `shop_categories_translations`
INNER JOIN `shop_categories` ON `shop_categories`.`id` = `shop_categories_translations`.`for_id`
WHERE `abbr` = 'en'
ORDER BY `position` ASC
ERROR - 2026-10-13 12:58:04 --> Query error: Unknown column 'shop_categories.image' in 'field list' - Invalid query: SELECT shop_categories.sub_for, shop_categories.id, shop_categories.image, shop_categories_translations.name, (SELECT COUNT(*) FROM products WHERE products.shop_categorie = shop_categories.id AND products.visibility = 1 AND products.quantity > 0 AND products.vendor_id = 0) AS product_count
FROM `shop_categories_translations`
INNER JOIN `shop_categories` ON `shop_categories`.`id` = `shop_categories_translations`.`for_id`
WHERE `abbr` = 'en'
ORDER BY `position` ASC
ERROR - 2026-10-13 13:43:37 --> 404 Page Not Found: ../modules/Vendor/controllers//index
ERROR - 2026-10-13 13:43:37 --> 404 Page Not Found: ../modules/Vendor/controllers//index
ERROR - 2026-10-13 13:44:34 --> 404 Page Not Found: ../modules/Vendor/controllers//index
ERROR - 2026-10-13 13:46:57 --> Severity: 8192 --> Optional parameter $page declared before required parameter $vendor is implicitly treated as a required parameter C:\Users\rashid\Documents\GitHub\Ecommerce-CodeIgniter-Bootstrap\application\controllers\Store.php 19
ERROR - 2026-10-13 13:46:57 --> Severity: 8192 --> Optional parameter $page declared before required parameter $vendor is implicitly treated as a required parameter C:\Users\rashid\Documents\GitHub\Ecommerce-CodeIgniter-Bootstrap\application\controllers\Store.php 19
ERROR - 2026-10-13 13:48:12 --> Severity: 8192 --> Optional parameter $page declared before required parameter $vendor is implicitly treated as a required parameter C:\Users\rashid\Documents\GitHub\Ecommerce-CodeIgniter-Bootstrap\application\controllers\Store.php 19
ERROR - 2026-10-13 14:32:50 --> Could not find the language line "show_menu"
ERROR - 2026-10-13 14:32:50 --> Could not find the language line "hide_menu"
ERROR - 2026-10-13 14:33:22 --> Could not find the language line "show_menu"
ERROR - 2026-10-13 14:33:22 --> Could not find the language line "hide_menu"
ERROR - 2026-10-13 14:33:28 --> Could not find the language line "show_menu"
ERROR - 2026-10-13 14:33:28 --> Could not find the language line "hide_menu"
ERROR - 2026-10-13 14:33:40 --> Could not find the language line "show_menu"
ERROR - 2026-10-13 14:33:40 --> Could not find the language line "hide_menu"
ERROR - 2026-10-13 14:39:15 --> 404 Page Not Found: /index
ERROR - 2026-10-13 15:55:33 --> 404 Page Not Found: /index
ERROR - 2026-10-13 15:55:36 --> 404 Page Not Found: /index
ERROR - 2026-10-13 16:12:30 --> 404 Page Not Found: Checkout/successPaymentPayPal
ERROR - 2026-10-13 16:14:17 --> Severity: Warning --> Undefined array key "u_email" C:\Users\rashid\Documents\GitHub\Ecommerce-CodeIgniter-Bootstrap\application\modules\vendor\models\Auth_model.php 32
ERROR - 2026-10-13 16:14:17 --> Severity: Warning --> Undefined array key "u_password_repeat" C:\Users\rashid\Documents\GitHub\Ecommerce-CodeIgniter-Bootstrap\application\modules\vendor\controllers\Auth.php 94
ERROR - 2026-10-13 16:14:17 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\Users\rashid\Documents\GitHub\Ecommerce-CodeIgniter-Bootstrap\application\modules\vendor\controllers\Auth.php 94
ERROR - 2026-10-13 16:14:17 --> Severity: Warning --> Undefined array key "u_password_repeat" C:\Users\rashid\Documents\GitHub\Ecommerce-CodeIgniter-Bootstrap\application\modules\vendor\controllers\Auth.php 97
ERROR - 2026-10-13 16:14:17 --> Severity: Warning --> Undefined array key "u_password_repeat" C:\Users\rashid\Documents\GitHub\Ecommerce-CodeIgniter-Bootstrap\application\modules\vendor\controllers\Auth.php 94
ERROR - 2026-10-13 16:14:17 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\Users\rashid\Documents\GitHub\Ecommerce-CodeIgniter-Bootstrap\application\modules\vendor\controllers\Auth.php 94
ERROR - 2026-10-13 16:14:17 --> Severity: Warning --> Undefined array key "u_password_repeat" C:\Users\rashid\Documents\GitHub\Ecommerce-CodeIgniter-Bootstrap\application\modules\vendor\controllers\Auth.php 97
ERROR - 2026-10-13 16:14:17 --> Severity: Warning --> Undefined array key "u_password_repeat" C:\Users\rashid\Documents\GitHub\Ecommerce-CodeIgniter-Bootstrap\application\modules\vendor\controllers\Auth.php 94
ERROR - 2026-10-13 16:14:17 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\Users\rashid\Documents\GitHub\Ecommerce-CodeIgniter-Bootstrap\application\modules\vendor\controllers\Auth.php 94
ERROR - 2026-10-13 16:14:17 --> Severity: Warning --> Undefined array key "u_password_repeat" C:\Users\rashid\Documents\GitHub\Ecommerce-CodeIgniter-Bootstrap\application\modules\vendor\controllers\Auth.php 97
ERROR - 2026-10-13 16:14:18 --> Severity: Warning --> Undefined array key "u_email" C:\Users\rashid\Documents\GitHub\Ecommerce-CodeIgniter-Bootstrap\application\modules\vendor\models\Auth_model.php 32
ERROR - 2026-10-13 16:14:57 --> Severity: Warning --> Undefined array key "u_email" C:\Users\rashid\Documents\GitHub\Ecommerce-CodeIgniter-Bootstrap\application\modules\vendor\models\Auth_model.php 32
ERROR - 2026-10-13 16:15:25 --> Severity: 8192 --> explode(): Passing null to parameter #2 ($string) of type string is deprecated C:\Users\rashid\Documents\GitHub\Ecommerce-CodeIgniter-Bootstrap\application\helpers\cleanreferral_helper.php 14
ERROR - 2026-10-13 16:15:27 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
ERROR - 2026-10-13 16:15:29 --> Severity: Warning --> Undefined array key "u_email" C:\Users\rashid\Documents\GitHub\Ecommerce-CodeIgniter-Bootstrap\application\modules\vendor\models\Auth_model.php 32
ERROR - 2026-10-13 16:15:30 --> Could not find the language line "vendor_home_page"
ERROR - 2026-10-13 16:20:05 --> Could not find the language line "show_menu"
ERROR - 2026-10-13 16:20:05 --> Could not find the language line "hide_menu"
ERROR - 2026-10-13 16:20:15 --> Could not find the language line "show_menu"
ERROR - 2026-10-13 16:20:15 --> Could not find the language line "hide_menu"
ERROR - 2026-10-13 16:20:17 --> Severity: Warning --> Undefined array key "u_email" C:\Users\rashid\Documents\GitHub\Ecommerce-CodeIgniter-Bootstrap\application\modules\vendor\models\Auth_model.php 32
ERROR - 2026-10-13 16:20:18 --> Could not find the language line "vendor_home_page"
ERROR - 2026-10-13 16:32:51 --> Severity: 8192 --> explode(): Passing null to parameter #2 ($string) of type string is deprecated C:\Users\rashid\Documents\GitHub\Ecommerce-CodeIgniter-Bootstrap\application\helpers\cleanreferral_helper.php 14
ERROR - 2026-10-13 16:32:53 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
ERROR - 2026-10-13 16:37:57 --> 404 Page Not Found: /index
ERROR - 2026-10-13 16:45:57 --> 404 Page Not Found: /index
ERROR - 2026-10-13 16:46:50 --> 404 Page Not Found: /index
ERROR - 2026-10-13 16:48:02 --> 404 Page Not Found: /index
ERROR - 2026-10-13 16:49:23 --> 404 Page Not Found: /index
ERROR - 2026-10-13 16:49:32 --> 404 Page Not Found: /index
ERROR - 2026-10-13 18:09:47 --> 404 Page Not Found: /index
ERROR - 2026-10-13 18:09:50 --> 404 Page Not Found: /index
