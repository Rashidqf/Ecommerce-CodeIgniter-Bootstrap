<?php

$lang['required'] = 'Pflichtfeld';

