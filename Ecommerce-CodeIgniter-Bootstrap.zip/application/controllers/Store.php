<?php

/*
 * Only vendors class
 */
defined('BASEPATH') OR exit('No direct script access allowed');

class Store extends MY_Controller
{

    private $num_rows = 20;

    public function __construct()
    {
        parent::__construct();
        $this->load->model('vendor/Vendorprofile_model');
    }

    public function index($page, $vendor)
    {
        if ((int) $this->Home_admin_model->getValueStore('multiVendor') !== 1) {
            show_404();
        }
        $vendorInfo = $this->Vendorprofile_model->getVendorByUrlAddress($vendor);
        if ($vendorInfo == null || (int) $vendorInfo['status'] !== 1) {
            show_404();
        }
        $data = array();
        $head = array();
        $head['title'] = $vendorInfo['name'];
        $head['description'] = lang('vendor_view') . $vendorInfo['name'];
        $head['keywords'] = $head['title'] !== null ? str_replace(" ", ",", $head['title']) : '';
        $head['vendor_url'] = LANG_URL . '/vendor/view/' . rawurlencode($vendor);
        $all_categories = $this->Public_model->getShopCategories();

        /*
         * Tree Builder for categories menu
         */

        function buildTree(array $elements, $parentId = 0)
        {
            $branch = array();
            foreach ($elements as $element) {
                if ($element['sub_for'] == $parentId) {
                    $children = buildTree($elements, $element['id']);
                    if ($children) {
                        $element['children'] = $children;
                    }
                    $branch[] = $element;
                }
            }
            return $branch;
        }

        $data['home_categories'] = $tree = buildTree($all_categories);
        $data['all_categories'] = $all_categories;
        $data['vendorInfo'] = $vendorInfo;
        $data['products'] = $this->Public_model->getProducts($this->num_rows, $page, $_GET, $vendorInfo['id'], true);
        $rowscount = $this->Public_model->productsCount($_GET, true, $vendorInfo['id']);
        $data['links_pagination'] = pagination('vendor/view/' . $vendor, $rowscount, $this->num_rows, 4);
        $this->render('buyora-vendor', $head, $data);
    }

    public function viewProduct($vendor, $id)
    {
        if ((int) $this->Home_admin_model->getValueStore('multiVendor') !== 1) {
            show_404();
        }
        $vendorInfo = $this->Vendorprofile_model->getVendorByUrlAddress($vendor);
        if ($vendorInfo == null || (int) $vendorInfo['status'] !== 1) {
            show_404();
        }
        $data = array();
        $head = array();
        $data['product'] = $this->Public_model->getOneProduct($id);
        if ($data['product'] === null || (int) $data['product']['vendor_id'] !== (int) $vendorInfo['id']) {
            show_404();
        }
        $data['sameCagegoryProducts'] = $this->Public_model->sameCagegoryProducts($data['product']['shop_categorie'], $id, $vendorInfo['id']);
        $data['storeProducts'] = $this->Public_model->getProducts(8, 0, array(), (int) $vendorInfo['id'], true);
        $vars['publicDateAdded'] = $this->Home_admin_model->getValueStore('publicDateAdded');
        $this->load->vars($vars);
        $head['title'] = $vendorInfo['name'] . ' - ' . $data['product']['title'];
        $head['vendor_url'] = LANG_URL . '/vendor/view/' . rawurlencode($vendorInfo['url']);
        $description = url_title(character_limiter(strip_tags($data['product']['description']), 130));
        $description = str_replace("-", " ", $description) . '..';
        $head['description'] = $description;
        $head['keywords'] = str_replace(" ", ",", $data['product']['title']);
        $data['vendorInfo'] = $vendorInfo;
        $this->render('buyora-product', $head, $data);
    }

}
